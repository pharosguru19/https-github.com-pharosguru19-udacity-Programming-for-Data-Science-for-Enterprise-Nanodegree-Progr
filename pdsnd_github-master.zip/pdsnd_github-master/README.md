1- added python code file and ignored the csv data files
2- Updated the python code by changing the message asking for user for city name
3- created a new branc callled refacctoring
4- updated the readme file indicating the last change in the python code
